### SE Project G24 进度跟踪表
最近更新时间: 2026.11.13
**项目DDL**: **2026.11.25** 
(!) 追加的'**线下Present时间**': 12.01(Tue) **16:30 - 17:00**, YEUNG B5-210
Present时间表 >> [Google Sheet链接](https://docs.google.com/spreadsheets/d/1YgpEjYyzoxWQfx1YKmsjKkzBbI27oPXXGLzEJU7R0hg/edit?usp=sharing)
当前项目问题汇总见 >> [点我跳转](#当前的问题)
***
#### 已经处理的事情
- 小组好了的队 (9月)
- 确认了项目选题: [Open Deep Search](https://github.com/langchain-ai/open_deep_research) (9月)
- 确定了每个人要处理的Issue (9月)
组员各自发现的Issues >> [Google Docs链接](https://docs.google.com/document/d/1uXVMrMW7F57Yc2XmDMPckGxn2tVe4P-1poj4xjWVuu0/edit?usp=sharing)
单独整理的Markdown表 >> [每个人认领的Requirement Markdown表](https://hackmd.io/@Tekkon/H1ODpACTMg/edit)
- 整理了详细易懂的整个项目流程 & 文档 (10月)
合并的'**总表**'见 >> https://hackmd.io/@Tekkon/S1XYAGGoMg/edit
- 将'汇总Markdown'拆成了各个独立的Markdown: [Google表格链接](https://docs.google.com/spreadsheets/d/1hWH1BsZ92N7WoCVbhSqcFCmakeK_oesAEq09p5CNZcY/edit?gid=0#gid=0)
***
#### 项目提交内容汇总
- 项目源码 + 各种内容 (.zip压缩包)
    注: **不包含**演示demo视频! 
- (★) demo视频
    时长: 10min
    内容:
    1. 展示项目'**改动前后**'的变化
    2. Highlight software engineering original ideas (我没太读懂这是什么意思)
    3. 展示项目的'**可追溯性**'(Traceability) 和 '**Agent治理**'(Agent Governance)
    - **可追溯性**: 展示一下'需求矩阵表' (简单介绍一下字段)
    - **Agent治理**: 整个Agent的处理流程 (如哪些地方有'人工介入' System Boundary, 利用'确定性'的方法来检查Research Agent输出的内容)

#### 预想流程
*仅供参考, 有想法可以直接改*
```text
1. 完成所有RE Markdown (所有人补完Requirement & 其他对应的Markdown)
    DDL: 11.10 (11.11 一个人统一Push到Github上)
    负责人: 所有人
    
2. 写一下(每个需求对应的)改进的架构文档 (下方Step 2)
    负责人: 所有人
    DDL: 11.15
    
2.5 统一合并的需求文档后, 每个人在利用自己的Agent实现各自的'需求测试'
    (搞完之后每个人对照看一看: AI给出来的验证方法有没有什么问题)
    负责人: 所有人
    DDL: 11.17
    
3. 一个人(+opencode)进行实现 & 验证 (跑前一个阶段定的测试)
    负责人: (待定)
    DDL: 11.19
    
4. 全体检查 + 进行新一轮迭代 
    (至少一轮, 每个人检查自己的部分有没有正确实现)
    DDL: 11.21 (最后迭代日期)
    
5. 录制Demo视频
    DDL: 11.23
    负责人(2+): (待定)
    
6. (追加) Present PPT 制作
    DDL: 11.29
    负责人: (待定)
    
7. 线下排练一遍PPT + 最终敲定
    DDL: 11.30
    负责人: 所有人
```

#### 参考细节
① 现在：HackMD 上写第 1–11 项（中文讨论 + 英文正式稿）
② 合并：把英文稿放进仓库对应的路径，开一个 PR，两人批准后进 main
③ 每个人从 main 拉出自己的分支，各自走一遍：
     Design：OpenCode 的 Plan Agent 读仓库里的 AGENTS.md → 蓝图 → 需求 → 不变量 → 约束，
             写出你的设计、评估表、ADR-002、测试计划
     → 人工批准（测试必须在实现前获批，课程的第一道门）
     Build：Build Agent 实现 src/ 和 test/
     Test：Test Agent 独立跑新测试 + 全部旧测试
     → 开 PR，两人批准、CI 通过，合并进 main //**这里就已经在进行合并测试了**
④ 六个人都合并后：只由一个人统一做集成测试、系统测试

***
#### 当前阶段
若某项文件'**已经完成**', 直接打√即可
(2026.11.10更新: 所有.md文件可以**直接点击'标题'进行链接跳转**)
- [x] 1. [Agent.md](https://hackmd.io/GY7GzcAtRxqupxig2gFIcw)
    状态: 基本完成, 待确认
    负责人: Alchemy

- [x] 2. [Requirements.yaml + req-schema.json](https://hackmd.io/@Tekkon/requirements_yaml/edit) 
    状态: 所有人已完成Requirements, 但部分需求描述存在冲突/重复 (正在进行统一排查修复...)
    - [x] req-schema.json (已于10.17敲定)
    - [x] Requirements.yamm (已完成6/6)
     请各位在这里补充完整 >> [共同Requirements.yaml书写区](https://hackmd.io/tJquZionQmaysZlzve6crQ?stext=4297%3A16%3A0%3A1794132623%3A_3AsSm&both=) <<
    负责人: Tekon & 所有人
    
    已写需求([点我跳转各自'认领'的Requirement](https://hackmd.io/@Tekkon/H1ODpACTMg/edit)):
        注: 经过协商, 我们决定在Owner一栏**仍用各位'昵称**' (已经帮各位处理好了)
        (我们在最后的**Contribution表**中写好'**昵称**'<-->'**个人姓名**'的对应关系就好了)
        Tekon准备将所有人的Owner一栏改回各自的'昵称'
        - REQ-002, 003 (Centay)
        - REQ-004（Jeremy）
        - REQ-005（Nancy）
        - REQ-006 (Tekon)
        - REQ-007 (Doppler)
        - REQ-008, 009 (Alchemy)
    写完后，重叠部分进行二次合并，不一致之处进行统一（待完成）；

    
    

- [x] 3. [Architecture-blueprint.md](https://hackmd.io/@Tekkon/architecture_blueprint/edit)
    补充字段定义: https://hackmd.io/@centay/Bkdq-wxAMx/edit
    状态: 
    - [x] 11.12号已完成 等大家md写完 我再跑一次opencode确认字段契约. 大家如果要测试(如Alchemy的交付规则)涉及到字段的话就需要看这里 
    负责人: Doppler, Centay

- [x] 4. [Invariants.md](https://hackmd.io/@Tekkon/invariants/edit)
    状态: 基本完成, 待确认 (Tekon对中文部分进行了移除, 备份了原始文档)
    负责人: Nancy, Jeremy

- [x] 5. [Permission-model.md + .opencode/permissions.jsonc](https://hackmd.io/@Tekkon/permission_model/edit)
    状态: 基本完成, 待确认 (Tekon对中文部分进行了移除, 备份了原始文档)
    负责人: Nancy, Jeremy

- [x] 6. [Prompt.md](https://hackmd.io/@Tekkon/prompt_md/edit) (Agent治理链的完成流程文字叙述)
    状态: Tekon使用了Markdown1, 3, 5, 8, 9, 10简单生成了该内容 (内部的`/docs/approvals/*`相关的内容可以全部移除, 只用`docs/ai-use-log.yaml`)
    负责人: ?

- [x] 7. [Trace-matrix.md](https://hackmd.io/@Tekkon/trace_matrix_md/edit)
    状态: 基本完成, 待确认
    负责人: Alchemy

- [x] 8. [docs/code-governance/structural-constraints.md](https://hackmd.io/@Tekkon/structural_constraints/edit)
    状态: **准备就绪**, 各位可以Agent交叉检查下, 等待进行整合 (已自行备份)
    负责人: Tekon

- [x] 9. [docs/code-governance/verification-constraints.md](https://hackmd.io/@Tekkon/verification_constraints/edit)
    状态: **准备就绪**, 同上, 等待进行整合 (已自行备份)
    负责人: Tekon
    
- [x] 10. [.opencode/rules.md + .agent/rules.md](https://hackmd.io/@Tekkon/rules/edit)
    状态: 基本完成, 待确认
    负责人: Alchemy

- [x] 11. [.github/workflows/ci.yml](https://hackmd.io/@Tekkon/ci_yml/edit)
    状态: 部分完成，后续进行修订
    负责人: Alchemy

***
Step 2: Software Architechure
这一步请参考 >> [Agent.md #3.2 Software Architecture](https://hackmd.io/GY7GzcAtRxqupxig2gFIcw?stext=6093%3A25%3A0%3A1794383217%3AMLqhhE&view=)
对于每个人各自的Requirement来说, 需要实现的东西各不一样 (比如说有的Requirement会涉及到'Agent记忆处理', 因此要在`docs/architecture/memory-design.md`实现对应的内容, 有的Requirement则不用)
***
### 当前的问题
(欢迎各位答疑 & 补充)
- [x] 在完成了'总需求列表'(2. Requirements.yaml)后, 要创建对应需求的'测试'程序吗? 还是说在所有需求明确之后, 直接让各位开始用opencode开始修复功能, 实现对应的功能后再做测试?
**Answer**: 
课程里提到实现之前测试已经获批, 所以可能是先**各自写自己需求的测试**,然后每次合并都再测整体 -centay
2. ...
